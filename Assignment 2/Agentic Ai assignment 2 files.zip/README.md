# 🤖 Autonomous Research Agent — LangChain + Claude

**Assignment 2 | AI Agent that researches topics and generates structured reports**

---

## 🏗️ Architecture

```
User Input (Topic)
      │
      ▼
┌─────────────────────────────────────────┐
│         ReAct Agent (LangChain)         │
│                                         │
│  Thought → Action → Observation loop   │
│                                         │
│  Tools Available:                       │
│  ┌──────────────┐  ┌─────────────────┐ │
│  │  WebSearch   │  │   Wikipedia     │ │
│  │  (Tavily)    │  │  Knowledge Tool │ │
│  └──────────────┘  └─────────────────┘ │
└─────────────────────────────────────────┘
      │
      ▼
 JSON Report Data
      │
      ▼
 Formatted Report
  ┌─────────────────────┐
  │  • Cover Page       │
  │  • Introduction     │
  │  • Key Findings     │
  │  • Challenges       │
  │  • Future Scope     │
  │  • Conclusion       │
  │  • Sources          │
  └─────────────────────┘
```

## 🛠️ Tech Stack

| Component | Technology |
|-----------|-----------|
| Agent Framework | LangChain (ReAct Agent) |
| LLM | Anthropic Claude (claude-sonnet) |
| Web Search | Tavily Search API |
| Knowledge Tool | Wikipedia (LangChain Community) |
| Language | Python 3.10+ |

## 📦 Installation

```bash
git clone https://github.com/yourusername/autonomous-research-agent
cd autonomous-research-agent

pip install -r requirements.txt
```

## 🔑 Environment Variables

Create a `.env` file:
```env
ANTHROPIC_API_KEY=your_anthropic_api_key_here
TAVILY_API_KEY=your_tavily_api_key_here
```

Get your free Tavily API key at: https://tavily.com

## 🚀 Usage

```bash
python agent.py
# Enter research topic: Impact of AI in Healthcare
```

The agent will:
1. **Search Wikipedia** for foundational knowledge
2. **Search the web** via Tavily for current developments
3. **Search for challenges** and criticisms
4. **Search for future trends** and predictions
5. **Generate a structured report** saved as a `.txt` file

## 📋 Sample Outputs

- `sample_output_1_ai_healthcare.txt` — Impact of AI in Healthcare
- `sample_output_2_quantum_computing.txt` — Future of Quantum Computing

## 🧩 How the ReAct Agent Works

The agent uses the **ReAct (Reasoning + Acting)** pattern:

```
Thought: I need to understand what AI in healthcare means broadly
Action: Wikipedia
Action Input: Artificial Intelligence in Healthcare
Observation: [Wikipedia content returned]

Thought: Now I need current statistics and recent developments
Action: WebSearch
Action Input: AI healthcare market size 2024 statistics
Observation: [Web search results returned]

Thought: I should find the main challenges
Action: WebSearch
Action Input: AI healthcare challenges bias regulation 2024
Observation: [Results returned]

Thought: Now I have enough to generate the report
Final Answer: <REPORT_DATA>{...json...}</REPORT_DATA>
```

## 📁 Project Structure

```
autonomous-research-agent/
├── agent.py                          # Main agent code
├── requirements.txt                  # Dependencies
├── README.md                         # This file
├── .env.example                      # Environment variables template
├── sample_output_1_ai_healthcare.txt
└── sample_output_2_quantum_computing.txt
```

## ✅ Assignment Requirements Checklist

- [x] Uses LangChain
- [x] Uses Anthropic Claude LLM
- [x] Tool 1: Web Search (Tavily)
- [x] Tool 2: Wikipedia Knowledge Tool
- [x] Implements ReAct Agent
- [x] Report includes: Cover Page, Title, Introduction, Key Findings, Challenges, Future Scope, Conclusion
- [x] 2 Sample Outputs provided

---
*Built for AI Engineering Assignment 2*
